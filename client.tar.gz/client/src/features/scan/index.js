import Scan from './containers/Scan'

export { Scan }
