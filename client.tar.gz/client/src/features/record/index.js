import Record from './containers/Record'

export { Record }
