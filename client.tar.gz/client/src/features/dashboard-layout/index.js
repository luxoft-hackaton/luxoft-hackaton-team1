import Dashboard from './containers/Dashboard'

export { Dashboard }
