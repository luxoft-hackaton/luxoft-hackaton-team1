import SidebarContent from './SidebarContent'

export default SidebarContent
