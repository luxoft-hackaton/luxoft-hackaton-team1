import ProtectedContent from './protected-content-container'

export default ProtectedContent
