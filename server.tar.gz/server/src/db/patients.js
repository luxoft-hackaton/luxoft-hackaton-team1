const { getDb, PATIENTS_COLLECTION } = require('./mongo')

/**
 * Creates patient record
 */
exports.add = async data => {
  const db = await getDb()
  await db.collection(PATIENTS_COLLECTION).insertOne(data)
  return data
}

/**
 * Create or update patient
 */
exports.createOrUpdate = async (publicKey, optionalFields) => {
  if (!publicKey) {
    throw new Error('publicKey is empty')
  }
  const db = await getDb()
  const data = { publicKey }
  const update = optionalFields ? { $set: optionalFields } : null
  const collection = db.collection(PATIENTS_COLLECTION)
  const record = await collection.findOne(data)
  if (record) {
    await collection.updateOne(data, { $set: { ...(optionalFields || {}), updatedAt: new Date() } })
  } else {
    await collection.insertOne({ ...data, ...optionalFields, createdAt: new Date(), updatedAt: new Date() })
  }
  return data
}
