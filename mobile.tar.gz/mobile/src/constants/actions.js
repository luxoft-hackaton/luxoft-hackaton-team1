export const REQUEST = 'REQUEST'
export const SUCCESS = 'SUCCESS'
export const FAIL = 'FAIL'

export const OPEN_NOTIF = 'OPEN_NOTIF'
export const CLOSE_NOTIF = 'CLOSE_NOTIF'

export const LOGIN = 'LOGIN'
export const LOGOUT = 'LOGOUT'
export const CHECK_LOGIN = 'CHECK_LOGIN'

export const ADD_RECORD = 'ADD_RECORDS'
export const UPDATE_RECORDS = 'UPDATE_RECORDS'

export const SHARE = 'SHARE'
export const CLEAR_SHARE_ID = 'CLEAR_SHARE_ID'
export const DATA_TO_SAVE = 'DATA_TO_SAVE'
