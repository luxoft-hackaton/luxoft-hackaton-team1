export const BASE_URL = process.env.REACT_APP_API_URL
export const BASE_URL_IPFS = 'http://172.27.138.74:8080'
export const INDEX = '/platform/address-indexes'
export const STORAGE = '/storage'

