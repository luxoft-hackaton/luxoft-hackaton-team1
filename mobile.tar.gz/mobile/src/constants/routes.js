const HOME = '/'
const LOGIN = '/login'
const HISTORY = '/history'
const SCAN = '/scan'

export {
  HOME,
  LOGIN,
  HISTORY,
  SCAN
}
