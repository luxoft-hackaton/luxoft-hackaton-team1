import Snackbar from './snackbar'

export default Snackbar