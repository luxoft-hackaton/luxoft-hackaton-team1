import ProtectedRoute from './protected-route-container'

export default ProtectedRoute
