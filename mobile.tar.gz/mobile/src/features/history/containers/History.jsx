import React, { Component } from 'react'
import { compose } from 'redux'
import { connect } from 'react-redux'
import { withStyles } from '@material-ui/core/styles';
import {
  Paper,
  Table,
  Divider,
  TableHead,
  TablePagination,
  Typography,
  Grid,
  Toolbar,
  Tooltip,
  Button,
  TableRow,
  TableCell,
  TableBody,
  Checkbox,
  TableSortLabel,
  Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions
} from '@material-ui/core';
import { CloudUpload } from '@material-ui/icons'

import { closeNotif, shareRecords, clearShareId } from '@root/store/common/actions'
import { MenuBtn } from '@root/components/buttons'
import { getSorting, stableSort } from '@root/utils'
import moment from "moment";

const styles = theme => ({
  maxWidth: {
    width: '100%'
  },
  title: {
    color: theme.palette.primary.dark
  },
  dialogTitle: {
    fontSize: '20px',
    fontFamily: theme.typography.fontFamily,
    color: theme.palette.primary.dark
  },
  padding: {
    padding: theme.spacing.unit * 2
  },
  padding1: {
    paddingLeft: theme.spacing.unit,
    paddingRight: theme.spacing.unit,
    '&:last-child': {
      paddingRight: theme.spacing.unit,
    }
  },
  toolbar: {
    display: 'flex',
    justifyContent: 'center'
  },
  darkBody: {
    backgroundColor: theme.palette.primary.dark
  },
  icon: {
    marginLeft: theme.spacing.unit
  }
})

const mockData = [
  {
    link: 'asdgsd',
    data: {
      _id: 'safd',
      createdAt: 1543778141574,
      doctorName: 'Petrov Ivan Nikolaevich',
      clinicName: 'Medical Center',
      notes: ['adsf', 'sadf', 'asd', 'adfg'],
      ipfsFiles: [],
      publicKey: 'ssda34c35v'
    }
  },
  {
    link: 'asdjgsd',
    data: {
      _id: 'q3f35',
      createdAt: 1543778141574,
      doctorName: 'Petrov Ivan Nikolaevich',
      clinicName: 'test',
      notes: ['adsf', 'sadf', 'asd', 'adfg'],
      ipfsFiles: [],
      publicKey: 'ssda3v5546v4c35v'
    }
  },
  {
    link: 'asddfsd',
    data: {
      _id: '3v5v3v',
      createdAt: 154377832111111,
      doctorName: 'Petrov Ivan Nikolaevich',
      clinicName: 'Medical Center',
      notes: ['adsf', 'sadf', 'asd', 'adfg'],
      ipfsFiles: [],
      publicKey: 'v34v345'
    }
  },
  {
    link: 'asdasdsd',
    data: {
      _id: 'v33v',
      createdAt: 1543723456345,
      doctorName: 'Petrov Ivan Nikolaevich',
      clinicName: 'Medical Center',
      notes: ['adsf', 'sadf', 'asd', 'adfg'],
      ipfsFiles: [],
      publicKey: '45v345v'
    }
  }
]


class History extends Component {
  constructor() {
    super()

    this.state = {
      order: 'asc',
      orderBy: 'createdAt',
      selected: [],
      page: 0,
      rowsPerPage: 5,
    };
  }

  componentDidUpdate(prevProps){
    if(prevProps.tempKey && this.props.tempKey !== prevProps.tempKey) {
      this.setState({ selected: [] })
    }
  }

  handleRequestSort = property => {
    const orderBy = property;
    let order = 'desc';

    if (this.state.orderBy === property && this.state.order === 'desc') {
      order = 'asc';
    }

    this.setState({ order, orderBy });
  };

  handleSelectAllClick = event => {
    if (event.target.checked) {
      this.setState({ selected: this.props.records.map(record => record.link) })
      return;
    }
    this.setState({ selected: [] });
  };

  isSelected = id => this.state.selected.indexOf(id) !== -1;

  handleClick = (event, id) => {
    const { selected } = this.state;
    const selectedIndex = selected.indexOf(id);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, id);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      );
    }

    this.setState({ selected: newSelected });
  };

  handleChangePage = (event, page) => {
    this.setState({ page });
  };

  handleChangeRowsPerPage = event => {
    this.setState({ rowsPerPage: event.target.value });
  };

  render() {
    const { classes, tempKey, clearShareId } = this.props
    const { order, selected, orderBy, page, rowsPerPage } = this.state
    const records = mockData
    const emptyRows = rowsPerPage - Math.min(rowsPerPage, records.length - page * rowsPerPage);
    console.log(records);
    return (
      <Grid container direction="column" alignItems="flex-start" className={classes.padding}>
        <Typography className={classes.title} variant="h5" gutterBottom>History</Typography>
        <Paper square className={classes.maxWidth}>
          <Toolbar className={classes.toolbar}>
            <Grid container justify="space-between" alignItems="center">
              <Typography color="inherit" variant="subtitle1">
                {selected.length} selected
              </Typography>
              <Tooltip title="Delete">
                <Button color="primary" variant="contained" onClick={() => this.props.shareRecords(selected)} >share<CloudUpload className={classes.icon}/></Button>
              </Tooltip>
            </Grid>
          </Toolbar>
          <Divider className={classes.darkBody} variant="middle"/>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                  <Checkbox
                    indeterminate={selected.length > 0 && selected.length < records.length}
                    checked={selected.length === records.length}
                    onChange={this.handleSelectAllClick} />
                </TableCell>
                <TableCell
                  padding="none"
                  sortDirection={orderBy === 'createdAt' ? order : false}>
                  <TableSortLabel
                    active={orderBy === 'createdAt'}
                    direction={order}
                    onClick={() => this.handleRequestSort('createdAt')}>
                    Created At
                  </TableSortLabel>
                </TableCell>
                <TableCell className={classes.padding1} sortDirection={orderBy === 'clinicName' ? order : false}>
                  <TableSortLabel
                    active={orderBy === 'clinicName'}
                    direction={order}
                    onClick={() => this.handleRequestSort('clinicName')}>
                    Clinic Name
                  </TableSortLabel>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {records && stableSort(records, getSorting(order, orderBy))
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map(record => {
                  console.log(records, 123);
                  const isSelected = this.isSelected(record.link)
                  return (
                    <TableRow
                      key={record.link}
                      hover
                      selected={isSelected} >
                      <TableCell
                        onClick={event => this.handleClick(event, record.link)}
                        padding="checkbox">
                        <Checkbox checked={isSelected} />
                      </TableCell>
                      <TableCell component="th" scope="row" padding="none">{moment(record.data.createdAt).format('DD.MM.YYYY')}</TableCell>
                      <TableCell className={classes.padding1}>{record.data.clinicName}</TableCell>
                    </TableRow>
                  )
                })}
              {emptyRows > 0 && (
                <TableRow style={{ height: 49 * emptyRows }}>
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
          </Table>
          <TablePagination
            rowsPerPageOptions={[5, 15, 25]}
            component="div"
            count={records.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onChangePage={this.handleChangePage}
            onChangeRowsPerPage={this.handleChangeRowsPerPage} />
        </Paper>
        <Dialog
          fullWidth
          open={!!tempKey} >
          <DialogTitle className={classes.dialogTitle} disableTypography>Shared code</DialogTitle>
          <DialogContent>
            <Paper>
              <DialogContentText>{tempKey}</DialogContentText>
            </Paper>
          </DialogContent>
          <Divider className={classes.darkBody} variant="middle"/>
          <DialogActions>
            <Button onClick={clearShareId} color="primary">OK</Button>
          </DialogActions>
        </Dialog>
      </Grid>
    )
  }
}

const mapStateToProps = state => ({
  records: state.records.records,
  auth: state.auth,
  open: state.notif.open,
  type: state.notif.type,
  message: state.notif.message,
  test: state.sharing,
  tempKey: state.sharing.tempKey
})

const mapDispatchToProps = {
  closeNotif,
  shareRecords,
  clearShareId
}

export default compose(withStyles(styles), connect(mapStateToProps, mapDispatchToProps))(History)
