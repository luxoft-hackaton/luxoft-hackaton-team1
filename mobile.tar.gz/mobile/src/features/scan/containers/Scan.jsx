import React, { Component } from 'react'
import { compose } from 'redux'
import { connect } from 'react-redux'
import { withStyles } from '@material-ui/core/styles';
import QrReader from "react-qr-reader";
import {Typography, Grid, Button, Card, CardActions, CardContent } from '@material-ui/core';

import { saveRecord, dataToSave } from '@root/store/common/actions'
import moment from "moment"

const styles = theme => ({
  padding: {
    height: '100%',
    padding: theme.spacing.unit * 2,
    overflowX: 'hidden',
    overflowY: 'auto',
  },
  dialogTitle: {
    width: '100%',
    color: theme.palette.primary.dark
  },
  qr: {
    width: '100%',
    maxWidth: 400
  },
  bold: {
    fontWeight: 'bold'
  }
})



class Scan extends Component {
  constructor(props) {
    super(props)

    this.state = {
      IPFSlink: null,
    };
  }

  handleScan = data => {
    if (data && !this.state.IPFSlink) {
      this.setState(prevState => ({IPFSlink: !prevState.IPFSlink ? data : prevState.IPFSlink}))
      this.props.dataToSave(data)
    }
  }


  render() {
    const { classes, saveRecord, recordToSave } = this.props
    const { IPFSlink } = this.state
    console.log(recordToSave);
    return (
      <Grid container className={classes.padding}>
        <Typography className={classes.dialogTitle} variant="h5" gutterBottom>Scan QR</Typography>
        {
          !IPFSlink
            ? <QrReader
              onError={() => null}
              onScan={this.handleScan}
              className={classes.qr} />
            : (recordToSave && <Card>
              <CardContent>
                <Typography className={classes.bold} variant="h5" gutterBottom>{recordToSave.clinicName}</Typography>
                <Typography variant="h6" gutterBottom>
                  Doctor: <span className={classes.bold}>{recordToSave.doctorName}</span>
                </Typography>
                <Typography variant="subtitle1" gutterBottom>{recordToSave.notes[0]}</Typography>
                <Typography variant="subtitle2" >Date: {moment(recordToSave.createdAt).format('DD MMM YYYY')}</Typography>
              </CardContent>
              <CardActions>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => saveRecord(IPFSlink)}>
                  Save record
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => this.setState({selectedData: null})}>
                  Cancel
                </Button>
              </CardActions>
            </Card>)
        }
      </Grid>
    )
  }
}

const mapStateToProps = state => ({
  recordToSave: state.sharing.recordToSave
})

const mapDispatchToProps = {
  saveRecord,
  dataToSave
}

export default compose(withStyles(styles), connect(mapStateToProps, mapDispatchToProps))(Scan)
