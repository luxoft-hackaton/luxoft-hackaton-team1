import React, { Component } from 'react'
import { compose } from 'redux'
import { connect } from 'react-redux'
import { withRouter } from "react-router-dom"
import { object, arrayOf, node, oneOfType } from 'prop-types'
import { withStyles } from '@material-ui/core/styles';
import {Toolbar, Grid, BottomNavigation, BottomNavigationAction, Divider} from '@material-ui/core';
import { Drafts, Star, Send, } from '@material-ui/icons';

import { closeNotif } from '@root/store/common/actions'
import { MenuBtn } from '@root/components/buttons'
import Header from '@root/components/header'
import Sidebar from '@root/components/sidebar'
import Logo from '@root/components/logo'
import Snackbar from '@root/components/snackbar'
import { HISTORY, SCAN } from '@root/constants/routes'

import SidebarContent from '../components/sidebar-content'

const styles = theme => ({
  root: {
    width: '100%',
    flexGrow: 1,
    height: '100vh',
    zIndex: 1,
    overflow: 'hidden',
    position: 'fixed',
    display: 'flex',
    flexDirection: 'column'
  },
  wrapper: {
    width: '100%',
    height: '100%',
    overflowX: 'hidden',
    overflowY: 'auto'
  },
  menuButton: {
    marginLeft: theme.spacing.unit * 1,
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing.unit * 2
    }
  },
  hidden: {
    width: '100%',
    visibility: 'hidden'
  },
  nav: {
    zIndex: 1,
    position: 'fixed',
    bottom: 0,
    left: 0,
    right: 0
  },
  navItem: {
    width: '33.33%',
    maxWidth: 'initial',
    border: `1px solid ${theme.palette.primary.main}`,
    backgroundColor: theme.palette.white
  }
})

class MainLayout extends Component {
  static propTypes = {
    auth: object.isRequired,
    classes: object.isRequired,
    children: oneOfType([arrayOf(node), node]).isRequired
  }

  constructor(props) {
    super(props)
    this.state = { openDrawler: false, selectedTab: props.location.pathname }
  }

  toggleDrawler = () => this.setState(prevState => ({ openDrawler: !prevState.openDrawler }))

  handleChange = (event, value) => {
    this.props.history.push(value)
    this.setState({ selectedTab: value });
  };

  render() {
    const { auth, children, classes, closeNotif, open, type, message } = this.props
    const { openDrawler, selectedTab } = this.state

    return (
      <div className={classes.root}>
        <Header disableGutters>
          <Grid container alignItems="center">
            <Grid item xs={3}><MenuBtn btnClass={classes.menuButton} menuToggle={this.toggleDrawler} /></Grid>
            <Grid item xs={6} container justify="center"><Logo color="white"/></Grid>
            <Grid item xs={3} />
          </Grid>
        </Header>
        <Sidebar
          open={openDrawler}
          handleDrawerToggle={this.toggleDrawler} >
          <Toolbar disableGutters >
            <Grid container alignItems="center">
              <Grid item xs={3}><MenuBtn btnClass={classes.menuButton} menuToggle={this.toggleDrawler} /></Grid>
              <Grid item xs={6} container justify="center"><Logo color="primary"/></Grid>
              <Grid item xs={3} />
            </Grid>
          </Toolbar>
          <Divider />
          <SidebarContent toggleDrawler={this.toggleDrawler}/>
        </Sidebar>
        <BottomNavigation
          className={classes.nav}
          value={selectedTab}
          onChange={this.handleChange}
          showLabels >
          <BottomNavigationAction className={classes.navItem} label="History" icon={<Drafts />} value={HISTORY} />
          <BottomNavigationAction className={classes.navItem} label="Scan" icon={<Star />} value={SCAN} />
          <BottomNavigationAction className={classes.navItem} label="Nearby" icon={<Send />} value={HISTORY} />
        </BottomNavigation>
        <Toolbar className={classes.hidden}/>
        <Grid item xs={12} className={classes.wrapper}>
          { children }
        </Grid>
        <Toolbar className={classes.hidden}/>
        <Snackbar open={open} type={type} message={message} onClose={closeNotif}/>
      </div>
    )
  }
}

const mapStateToProps = state => ({
  auth: state.auth,
  open: state.notif.open,
  type: state.notif.type,
  message: state.notif.message
})

const mapDispatchToProps = {
  closeNotif
}

export default compose(withStyles(styles), connect(mapStateToProps, mapDispatchToProps), withRouter)(MainLayout)
