import axios from 'axios'
import { BASE_URL_IPFS } from '../constants/api'

export const getIPFSrecord = async ipfsLink => {
  console.log(ipfsLink);
  try {
    const res = await axios.get(`${BASE_URL_IPFS}/ipfs/${ipfsLink}`)
    if (res.errorType || res.errorMessage) throw res
    console.log(res);
    return res.data
  } catch (err) {
    throw err.errorMessage || err.message
  }
}
