import { DidManagerInstance, hexToAttribute, bytes32toString } from '@root/utils'

export const saveRecordToBlockchain = async (privKey, did, key, value) => {
  try {
    await DidManagerInstance.setAttribute(privKey, did, key, value)
  } catch (err) {
    throw err.errorMessage || err.message
  }
}

export const getRecordsFromBlockchain = async address => {
  try {
    const res = await DidManagerInstance.getHistory(address)
    return hexToAttribute(bytes32toString(res[0].event.name), res[0].event.value)
  } catch (err) {
    throw err.errorMessage || err.message
  }
}
