import { getIndex, increaseIndex } from './addr-index'
import { saveRecordToBlockchain, getRecordsFromBlockchain } from './blockchain'
import { shareRecordsApi } from './sharing'
import { getIPFSrecord } from './ipfs'

export {
  getIndex,
  increaseIndex,
  saveRecordToBlockchain,
  getRecordsFromBlockchain,
  shareRecordsApi,
  getIPFSrecord
}