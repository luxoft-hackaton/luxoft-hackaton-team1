import axios from 'axios'
import { BASE_URL, STORAGE } from '../constants/api'

export const shareRecordsApi = async (recordsIPFS, publicKey) => {
  try {
    const res = await axios.post(`${BASE_URL}${STORAGE}`, {publicKey, records: recordsIPFS})
    if (res.errorType || res.errorMessage) throw res

    return res.data
  } catch (err) {
    throw err.errorMessage || err.message
  }
}
