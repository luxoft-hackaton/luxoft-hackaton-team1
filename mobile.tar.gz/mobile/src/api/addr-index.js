import axios from 'axios'
import { BASE_URL, INDEX } from '../constants/api'

export const getIndex = async mnemonicHash => {
  try {
    const res = await axios.get(`${BASE_URL}${INDEX}/${mnemonicHash}`)
    if (res.errorType || res.errorMessage) throw res

    return res.data
  } catch (err) {
    throw err.errorMessage || err.message
  }
}

export const increaseIndex = async mnemonicHash => {
  try {
    await axios.patch(`${BASE_URL}${INDEX}/${mnemonicHash}`)
    if (res.errorType || res.errorMessage) throw res

  } catch (err) {
    throw err.errorMessage || err.message
  }
}