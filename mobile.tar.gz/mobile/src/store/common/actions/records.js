import { ADD_RECORD, REQUEST } from '@root/constants/actions'

export const saveRecord = record => ({
  type: `${REQUEST}_${ADD_RECORD}`,
  record
})
