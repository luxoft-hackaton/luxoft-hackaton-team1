import { login, logout, checkLogin } from './auth'
import { openNotif, closeNotif } from './notif'
import { saveRecord } from './records'
import { shareRecords, clearShareId, dataToSave } from './sharing'

export {
  login,
  logout,
  checkLogin,
  openNotif,
  closeNotif,
  saveRecord,
  shareRecords,
  clearShareId,
  dataToSave
}
