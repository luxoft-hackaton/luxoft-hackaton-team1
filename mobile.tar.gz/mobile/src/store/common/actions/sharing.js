import { SHARE, REQUEST, CLEAR_SHARE_ID, DATA_TO_SAVE } from '@root/constants/actions'

export const shareRecords = recordsIPFS => ({
  type: `${REQUEST}_${SHARE}`,
  recordsIPFS
})

export const dataToSave = IPFSlink => ({
  type: `${REQUEST}_${DATA_TO_SAVE}`,
  IPFSlink
})

export const clearShareId = () => ({
  type: `${CLEAR_SHARE_ID}`
})