import { SUCCESS, FAIL, REQUEST, SHARE, CLEAR_SHARE_ID, DATA_TO_SAVE } from '@root/constants/actions'

const initialState = {
  tempKey: null,
  recordToSave: null,
  fetching: false,
  error: null
}

export default (state = initialState, action) => {
  switch (action.type) {
    case `${REQUEST}_${DATA_TO_SAVE}`:
      return { ...initialState, fetching: true }
    case `${SUCCESS}_${DATA_TO_SAVE}`:
      return { ...state, fetching: false, recordToSave: action.recordToSave }
    case `${FAIL}_${DATA_TO_SAVE}`:
      return { ...state, fetching: false, error: action.error }

    case `${REQUEST}_${SHARE}`:
      return { ...initialState, fetching: true }
    case `${SUCCESS}_${SHARE}`:
      return { ...state, fetching: false, tempKey: action.tempKey }
    case `${FAIL}_${SHARE}`:
      return { ...state, fetching: false, error: action.error }

    case `${CLEAR_SHARE_ID}`:
      return { ...initialState }
    default:
      return state
  }
}
