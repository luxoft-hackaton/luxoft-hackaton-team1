import auth from './auth'
import notif from './notif'
import records from './records'
import sharing from './sharing'

export default {
  auth,
  notif,
  records,
  sharing
}
