import { SUCCESS, FAIL, REQUEST, LOGOUT, ADD_RECORD, UPDATE_RECORDS } from '@root/constants/actions'

const initialState = {
  addingRecord: false,
  fetching: false,
  error: null,
  recordsIPFS: [],
  records: []
}

export default (state = initialState, action) => {
  switch (action.type) {
    case `${REQUEST}_${ADD_RECORD}`:
      return { ...state, addingRecord: true, error: null }
    case `${SUCCESS}_${ADD_RECORD}`:
      return { ...state, addingRecord: false }
    case `${FAIL}_${ADD_RECORD}`:
      return { ...state, addingRecord: false, error: action.error }
    case `${REQUEST}_${UPDATE_RECORDS}`:
      return { ...state, fetching: true }
    case `${SUCCESS}_${UPDATE_RECORDS}`:
      return {
        ...state,
        fetching: false,
        records: action.recordsObj.records,
        recordsIPFS: action.recordsObj.records.map(record => record.link)
      }
    case `${LOGOUT}`:
      return { ...initialState }
    default:
      return state
  }
}
