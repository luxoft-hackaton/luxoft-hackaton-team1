import { put, takeLatest, call } from 'redux-saga/effects'
import hash from 'object-hash'

import { SHARE, REQUEST, SUCCESS, FAIL, DATA_TO_SAVE } from '@root/constants/actions'
import { StoredMnemonic, StoredRecords, DidManager } from '@root/utils'
import { shareRecordsApi, getIPFSrecord } from '@root/api'

export function* shareRecords({ recordsIPFS }) {
  const mnemonic = StoredMnemonic.get(mnemonic)
  try {
    const data = yield call(shareRecordsApi, recordsIPFS, hash(mnemonic))

    yield put({ type: `${SUCCESS}_${SHARE}`, tempKey: data.code })
  } catch (err) {
    yield put({ type: `${FAIL}_${SHARE}`, error: err.message || err })
  }
}

export function* dataToSave({ IPFSlink }) {
  try {
    const recordToSave = yield call(getIPFSrecord, IPFSlink)
    console.log(9999, recordToSave);
    yield put({ type: `${SUCCESS}_${DATA_TO_SAVE}`, recordToSave })
  } catch (err) {
    yield put({ type: `${FAIL}_${DATA_TO_SAVE}`, error: err.message || err })
  }
}

export default function sharingSaga() {
  return [
    takeLatest(`${REQUEST}_${DATA_TO_SAVE}`, dataToSave),
    takeLatest(`${REQUEST}_${SHARE}`, shareRecords)
  ]
}
