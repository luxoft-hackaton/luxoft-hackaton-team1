import { put, takeLatest, select, call } from 'redux-saga/effects'
import hash from 'object-hash'

import { ADD_RECORD, REQUEST, SUCCESS, FAIL, UPDATE_RECORDS } from '@root/constants/actions'
import { StoredRecords, DidManager } from '@root/utils'
import { getIndex, increaseIndex, saveRecordToBlockchain } from '@root/api'

export function* saveRecord({ record }) {
  const mnemonic = yield select(state => state.auth.mnemonic);
  const addrObj = yield call(getIndex, hash(mnemonic))
  console.log(record);
  try {
    const didObj = DidManager.generateDID(mnemonic, addrObj.index)
    yield call(saveRecordToBlockchain, didObj.privateKeyHex, didObj.did, 'did/svc/ipfs', record.link)
    const storedRecordsObj = StoredRecords.get()

    const recordsObj = { ...storedRecordsObj, records: [...storedRecordsObj.records, record] }

    yield put({ type: `${REQUEST}_${UPDATE_RECORDS}`, recordsObj })
    yield put({ type: `${SUCCESS}_${ADD_RECORD}`, record })
    yield call(increaseIndex, hash(mnemonic))
  } catch (err) {
    yield put({ type: `${FAIL}_${ADD_RECORD}`, error: err.message || err })
  }
}

export function* updateRecords({ recordsObj }) {
  StoredRecords.set(recordsObj)
  yield put({ type: `${SUCCESS}_${UPDATE_RECORDS}`, recordsObj })
}

export default function recordsSaga() {
  return [
    takeLatest(`${REQUEST}_${ADD_RECORD}`, saveRecord),
    takeLatest(`${REQUEST}_${UPDATE_RECORDS}`, updateRecords)
  ]
}
