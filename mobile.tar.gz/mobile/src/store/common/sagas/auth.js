import { put, takeLatest, call, all } from 'redux-saga/effects'
import hash from 'object-hash'

import { LOGIN, LOGOUT, CHECK_LOGIN, REQUEST, UPDATE_RECORDS } from '@root/constants/actions'
import { HOME } from '@root/constants/routes'
import { StoredMnemonic, StoredRecords, DidManager } from '@root/utils'
import { store } from '@root/store'
import { getIndex, getRecordsFromBlockchain, getIPFSrecord } from '@root/api'


export function* login({ mnemonic }) {
  StoredMnemonic.set(mnemonic)
  const record = yield call(getIndex, hash(mnemonic))
  console.log(record);
  let storedRecordsObj = StoredRecords.get()
  console.log(storedRecordsObj);
  if(!storedRecordsObj || hash(storedRecordsObj.mnemonic) !== record.mnemonicHash) {
    storedRecordsObj = { mnemonic, records: [] }
  }

  if(record.index !== 0) {
    if(storedRecordsObj.records.length !== record.index) {
      const addresses = []
      for(let i = storedRecordsObj.records.length; i < record.index; i++) {
        const didObj = DidManager.generateDID(mnemonic, i)
        addresses.push(didObj.address)
      }

      const blockchainRecords = yield all(
        addresses.map(addr => call(getRecordsFromBlockchain, addr))
      )
      console.log(blockchainRecords);

      const ipfsRecords = blockchainRecords.map(blrecord => ({
        link: blrecord,
        data: null
      }))

      const prevRecords = storedRecordsObj.records

      console.log(ipfsRecords);
      const recordsData = yield all(
        ipfsRecords.map(recObj => ({
          data: call(getIPFSrecord, recObj.link),
          link: recObj.link
        }))
      )

      console.log(recordsData);
      storedRecordsObj.records = [ ...prevRecords, ...recordsData.map((recordData, idx) => ({link: ipfsRecords[idx], data: recordData})) ]

      console.log(recordsData);
      //todo and store in redux/localstorage
    }
  }

  yield put({ type: `${REQUEST}_${UPDATE_RECORDS}`, recordsObj: storedRecordsObj })

  yield put({ type: `${LOGIN}`, payload: { mnemonic } })
}

export function* logout() {
  StoredMnemonic.remove()

  yield put({ type: `${LOGOUT}` })
}

export function* checkLogin() {
  const mnemonic = StoredMnemonic.get()

  if(!mnemonic) return
  yield put({ type: `${REQUEST}_${LOGIN}`, mnemonic })
}



export default function accountsSaga() {
  return [
    takeLatest(`${REQUEST}_${LOGIN}`, login),
    takeLatest(`${REQUEST}_${LOGOUT}`, logout),
    takeLatest(`${CHECK_LOGIN}`, checkLogin)
  ]
}
