import auth from './auth'
import records from './records'
import sharing from './sharing'

export default function () {
  return [
    ...auth(),
    ...records(),
    ...sharing()
  ]
}
