import { BN } from 'ethereumjs-util'
import { find } from 'lodash'
import { sign } from 'ethjs-signer'
import {  toWei } from 'ethjs-unit'
import { encodeMethod, logDecoder } from 'ethjs-abi'
import DidRegistryABI from 'ethr-did-resolver/contracts/ethr-did-registry.json'

import { stringToBytes32, attributeToHex } from './formatting'

export default class TransactionManager {
  static signTx = (privateKey, rawTx) => sign(rawTx, privateKey)

  static getUpfrontCost = rawTx => {
    if (!rawTx.gasLimit || !rawTx.gasPrice) throw new Error('Missing required parameter')

    return new BN(rawTx.gasLimit)
      .imul(new BN(rawTx.gasPrice))
      .iadd(new BN(rawTx.value))
  }

  constructor(ethInstance, didRegistryInstance, registryAddr) {
    this.ethInstance = ethInstance
    this.didRegistryAddress = registryAddr
    this.didRegistryInstance = didRegistryInstance
    this.donatorAddress = process.env.REACT_APP_DONATOR
    this.DidRegistryABI = DidRegistryABI

    this.txConstants = {
      TX_NO_BYTECODE: '0x',
      TX_GAS_PRICE: toWei(100, 'gwei'),
      TX_GAS_LIMIT: 100000
    }
  }

  async lastChanged(identity) {
    const result = await this.didRegistryInstance.changed(identity)
    if (result) {
      return result['0']
    }
  }

  async getDidEventHistory(identity) {
    let history = []

    let previousChange = await this.lastChanged(identity)

    while (previousChange) {
      const blockNumber = previousChange.toNumber()
      const block = await this.ethInstance.getBlockByNumber(blockNumber, true)
      const timestamp = block ? block.timestamp : 0 // getBlockByNumber might fail and return undefined

      const logs = await this.ethInstance.getLogs({
        address: this.didRegistryAddress,
        topics: [null, `0x000000000000000000000000${identity.slice(2)}`],
        fromBlock: previousChange,
        toBlock: previousChange
      })

      const events = logDecoder(this.DidRegistryABI, false)(logs)

      previousChange = undefined
      for (let event of events) {
        history = [ { blockNumber, timestamp, event }, ...history ]
        previousChange = event.previousChange
      }
    }

    return history
  }

  async sendRawTransaction(tx) {
    const txHash = await this.ethInstance.sendRawTransaction(tx)
    return await this.waitBlock(txHash)
  }

  async calcExtraFundsRequired(senderAddress, amountWei) {
    const senderBalance = await this.ethInstance.getBalance(senderAddress, 'latest')
    return senderBalance.ucmp(amountWei) === -1 ? amountWei.sub(senderBalance) : new BN(0)
  }

  async getRawTx(txData) {
    const nonce = await this.ethInstance.getTransactionCount(txData.from, 'pending')
    const rawTx = {
      from: txData.from,
      to: txData.to,
      data: txData.data || this.txConstants.TX_NO_BYTECODE,
      nonce,
      value: txData.value,
      gasPrice: this.txConstants.TX_GAS_PRICE,
      gasLimit: this.txConstants.TX_GAS_LIMIT
    }

    if(txData.contractABI && txData.methodName && txData.params)
      rawTx.data = encodeMethod(find(txData.contractABI, { name: txData.methodName }), txData.params)

    return rawTx
  }

  async waitBlock(txHash) {
    let times = 0
    const interval = 4000
    const timeout = 60000

    while (true || (times * interval <= timeout) ) {
      try {
        const receipt = await this.ethInstance.getTransactionReceipt(txHash)
        return receipt.status === '0x1'
      } catch (e) {
        if (times * (interval + 1) > timeout) throw new Error(`Waiting block for more then ${timeout} ms`)
        console.log(`Mining...`)
        await (new Promise(resolve => setTimeout(resolve, interval)))
      }
      times++
    }
  }

  async sendFunds(rawTx) {
    const extra = await this.calcExtraFundsRequired(rawTx.from, TransactionManager.getUpfrontCost(rawTx))

    if(extra) {
      const tx = await this.getRawTx({
        from: this.donatorAddress,
        to: rawTx.from,
        value: extra
      })

      const txHash = await this.ethInstance.sendTransaction(tx)
      return await this.waitBlock(txHash)
    }
  }

  async setAttributeTx(address, key, value, expiresIn ) {
    const attrKey = stringToBytes32(key)
    const attrValue = attributeToHex(key, value)
    const txData = {
      from: address,
      to: this.didRegistryAddress,
      contractABI: this.DidRegistryABI,
      methodName: 'setAttribute',
      params: [
        address,
        attrKey,
        attrValue,
        expiresIn
      ]
    }

    return await this.getRawTx(txData)
  }
}
