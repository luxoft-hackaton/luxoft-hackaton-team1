import { HDNode } from 'ethers'
import DidRegistryABI from 'ethr-did-resolver/contracts/ethr-did-registry.json'
import Eth from 'ethjs-query'
import HttpProvider from 'ethjs-provider-http'
import EthContract from 'ethjs-contract'

import TransactionManager from './TransactionManager'
import { privateKeyToEthereumAddress } from './formatting'

export class DidManager {
  static generateDID = (mnemonic, index) => {
    const masterNode = HDNode.fromMnemonic(mnemonic)
    const addressNode = masterNode.derivePath(`m/44'/60'/0'/0/${index}`)
    const address = privateKeyToEthereumAddress(addressNode.privateKey)
    return {
      publicKeyHex: addressNode.publicKey,
      privateKeyHex: addressNode.privateKey,
      address,
      did: `did:ethr:${address}`
    }
  }

  constructor({ registryAddr }) {
    this.ethInstance = new Eth(new HttpProvider(`${process.env.REACT_APP_BLOCKCHAIN_HOST}:${process.env.REACT_APP_BLOCKCHAIN_PORT}`))
    this.didRegistryInstance = (new EthContract(this.ethInstance))(DidRegistryABI).at(registryAddr)

    this.TransactionManager = new TransactionManager(this.ethInstance, this.didRegistryInstance, registryAddr)
  }

  async getHistory(address) {
    const res = await this.TransactionManager.getDidEventHistory(address)
    return res
  }

  async setAttribute(privateKey, did, key, value, expiresIn = 8640000) {
    const rawTx = await this.TransactionManager.setAttributeTx(did.slice(9), key, value, expiresIn )
    const txStatus = await this.TransactionManager.sendFunds(rawTx)
    if(!txStatus) throw new Error('Funding transaction failed')

    const signedTx = await TransactionManager.signTx(privateKey, rawTx)
    console.log(signedTx);
    return await this.TransactionManager.sendRawTransaction(signedTx)
  }
}

export const DidManagerInstance = new DidManager({
  registryAddr: process.env.REACT_APP_REGISTRY_CONTRACT
})
