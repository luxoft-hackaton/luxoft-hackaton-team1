import { theme } from './theme'
import { LocalStorageItem, StoredMnemonic, StoredRecords } from './storageItem'
import { getSorting, stableSort } from './sort-filter'
import { registerSW } from './registerSW'
import { DidManager, DidManagerInstance } from './did-manager/DidManager'
import {
  hexToAttribute,
  bytes32toString,
  attributeToHex,
  privateKeyToEthereumAddress,
  publicKeyToEthereumAddress,
  stringToBytes32
} from './did-manager/formatting'

export {
  theme,
  registerSW,
  LocalStorageItem,
  StoredMnemonic,
  StoredRecords,
  getSorting,
  stableSort,
  DidManager,
  hexToAttribute,
  bytes32toString,
  attributeToHex,
  privateKeyToEthereumAddress,
  publicKeyToEthereumAddress,
  stringToBytes32,
  DidManagerInstance
}
