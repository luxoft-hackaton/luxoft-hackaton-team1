import React from 'react'
import { Switch, Redirect, Route } from 'react-router'

import ProtectedRoute from '@root/components/protected-route'
import { Dashboard } from '@root/features/dashboard-layout'

import { LOGIN, HOME, HISTORY, SCAN } from '@root/constants/routes'
import { Login } from '@root/features/auth'
import { History } from '@root/features/history'
import { Scan } from '@root/features/scan'

const MainRoutes = () => (
  <Dashboard>
    <Switch>
      <Route exact path={HISTORY} component={History} />
      <Route exact path={SCAN} component={Scan} />
      <Redirect from="/" to={HISTORY} />
    </Switch>
  </Dashboard>
)

const Routes = () => (
  <Switch>
    <ProtectedRoute
      exact
      path={LOGIN}
      pathToRedirect={HOME}
      checkPermission={store => !store.isLoggedIn}
      component={Login} />
    <ProtectedRoute
      path={HOME}
      pathToRedirect={LOGIN}
      checkPermission={store => store.isLoggedIn}
      component={MainRoutes} />
  </Switch>
)

export default Routes
