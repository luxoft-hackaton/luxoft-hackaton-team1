import Routes from './routes'

export default Routes
